<?php

/* default/template/common/home.twig */
class __TwigTemplate_d0e2e1b0d52de4f8f7ce121ae954fe71aaf825d437ff0a04547f90d376e358f1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo (isset($context["header"]) ? $context["header"] : null);
        echo "
<div id=\"common-home\">
  ";
        // line 3
        if ((isset($context["content_top"]) ? $context["content_top"] : null)) {
            // line 4
            echo "  <div  class=\"content_top\">
    <div  class=\"container\">
      <div class=\"row\">
        <div class=\"col-sm-3 hidden-md-down\">
          ";
            // line 8
            echo (isset($context["menu"]) ? $context["menu"] : null);
            echo "
        </div>
        ";
            // line 10
            if ((isset($context["column_right"]) ? $context["column_right"] : null)) {
                // line 11
                echo "        ";
                $context["top_class"] = "col-sm-6";
                // line 12
                echo "        ";
            } else {
                // line 13
                echo "        ";
                $context["top_class"] = "col-sm-9";
                // line 14
                echo "        ";
            }
            // line 15
            echo "        <div class=\"";
            echo (isset($context["top_class"]) ? $context["top_class"] : null);
            echo " home-slider-col\">
            ";
            // line 16
            echo (isset($context["content_top"]) ? $context["content_top"] : null);
            echo "
        </div>
        ";
            // line 18
            if ((isset($context["column_right"]) ? $context["column_right"] : null)) {
                // line 19
                echo "        ";
                echo (isset($context["column_right"]) ? $context["column_right"] : null);
                echo "
        ";
            }
            // line 21
            echo "      </div>
    </div>
  </div>
  ";
        }
        // line 25
        echo "  <div class=\"column_center\">
    <div class=\"container\">
      <div class=\"row\">
        ";
        // line 28
        if ((isset($context["column_left"]) ? $context["column_left"] : null)) {
            // line 29
            echo "        ";
            echo (isset($context["column_left"]) ? $context["column_left"] : null);
            echo "
        ";
        }
        // line 31
        echo "        ";
        if ((isset($context["column_left"]) ? $context["column_left"] : null)) {
            // line 32
            echo "        ";
            $context["class"] = "col-sm-9";
            // line 33
            echo "        ";
        } else {
            // line 34
            echo "        ";
            $context["class"] = "col-sm-12";
            // line 35
            echo "        ";
        }
        // line 36
        echo "        <div id=\"content\" class=\"";
        echo (isset($context["class"]) ? $context["class"] : null);
        echo "\">
          ";
        // line 37
        echo (isset($context["content_bottom"]) ? $context["content_bottom"] : null);
        echo "
        </div>
      </div>
    </div>
  </div>
</div>
";
        // line 43
        echo (isset($context["footer"]) ? $context["footer"] : null);
    }

    public function getTemplateName()
    {
        return "default/template/common/home.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 43,  108 => 37,  103 => 36,  100 => 35,  97 => 34,  94 => 33,  91 => 32,  88 => 31,  82 => 29,  80 => 28,  75 => 25,  69 => 21,  63 => 19,  61 => 18,  56 => 16,  51 => 15,  48 => 14,  45 => 13,  42 => 12,  39 => 11,  37 => 10,  32 => 8,  26 => 4,  24 => 3,  19 => 1,);
    }
}
/* {{ header }}*/
/* <div id="common-home">*/
/*   {% if content_top %}*/
/*   <div  class="content_top">*/
/*     <div  class="container">*/
/*       <div class="row">*/
/*         <div class="col-sm-3 hidden-md-down">*/
/*           {{ menu }}*/
/*         </div>*/
/*         {% if column_right %}*/
/*         {% set top_class = 'col-sm-6' %}*/
/*         {% else %}*/
/*         {% set top_class = 'col-sm-9' %}*/
/*         {% endif %}*/
/*         <div class="{{ top_class }} home-slider-col">*/
/*             {{ content_top }}*/
/*         </div>*/
/*         {% if column_right %}*/
/*         {{ column_right }}*/
/*         {% endif %}*/
/*       </div>*/
/*     </div>*/
/*   </div>*/
/*   {% endif %}*/
/*   <div class="column_center">*/
/*     <div class="container">*/
/*       <div class="row">*/
/*         {% if column_left %}*/
/*         {{ column_left }}*/
/*         {% endif %}*/
/*         {% if column_left %}*/
/*         {% set class = 'col-sm-9' %}*/
/*         {% else %}*/
/*         {% set class = 'col-sm-12' %}*/
/*         {% endif %}*/
/*         <div id="content" class="{{ class }}">*/
/*           {{ content_bottom }}*/
/*         </div>*/
/*       </div>*/
/*     </div>*/
/*   </div>*/
/* </div>*/
/* {{ footer }}*/
