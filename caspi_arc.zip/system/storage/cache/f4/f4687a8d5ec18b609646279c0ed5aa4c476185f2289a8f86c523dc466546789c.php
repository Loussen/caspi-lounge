<?php

/* default/template/extension/module/bestseller.twig */
class __TwigTemplate_3b55f3f5eeceaa89388c162c5a730c277c498d7e5a3ef8f17c8c7483700a705a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "    <section class=\"flat-imagebox bestsellerproducts\">
      <div class=\"container1\">
        <div class=\"row\">
          <div class=\"col-md-12\">
            <div class=\"product-tab\">
              <ul class=\"tab-list\">
                <li class=\"active\">";
        // line 7
        echo (isset($context["heading_title"]) ? $context["heading_title"] : null);
        echo "</li>
              </ul>
            </div><!-- /.product-tab -->
          </div><!-- /.col-md-12 -->
        </div><!-- /.row -->
        <div class=\"box-product\">
          <div class=\"row\">

              ";
        // line 15
        if (($this->getAttribute((isset($context["setting"]) ? $context["setting"] : null), "limit", array()) == 3)) {
            // line 16
            echo "                  ";
            $context["class"] = "col-lg-4 col-sm-6";
            // line 17
            echo "              ";
        } else {
            // line 18
            echo "                  ";
            $context["class"] = "col-lg-3 col-sm-6";
            // line 19
            echo "              ";
        }
        // line 20
        echo "
              ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["products"]) ? $context["products"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 22
            echo "                <div class=\"";
            echo (isset($context["class"]) ? $context["class"] : null);
            echo "\">
              <div class=\"product-box\">
                <div class=\"imagebox\">
                  <!--span class=\"item-new\">NEW</span-->
                  ";
            // line 26
            if ($this->getAttribute($context["product"], "special", array())) {
                // line 27
                echo "                  <span class=\"item-sale\">SALE</span>
                  ";
            }
            // line 29
            echo "                   <ul class=\"box-image owl-carousel-1\">
                    <li>
                      <a href=\"";
            // line 31
            echo $this->getAttribute($context["product"], "href", array());
            echo "\" title=\"";
            echo $this->getAttribute($context["product"], "name", array());
            echo "\">
                        <img src=\"";
            // line 32
            echo $this->getAttribute($context["product"], "thumb", array());
            echo "\" alt=\"";
            echo $this->getAttribute($context["product"], "name", array());
            echo "\">
                      </a>
                    </li>
                  </ul><!-- /.box-image -->
                  <div class=\"box-content\">
                    <div class=\"cat-name\">
                      ";
            // line 39
            echo "                    </div>
                    <div class=\"product-name\">
                      <a href=\"";
            // line 41
            echo $this->getAttribute($context["product"], "href", array());
            echo "\" title=\"";
            echo $this->getAttribute($context["product"], "name", array());
            echo "\">";
            echo $this->getAttribute($context["product"], "name", array());
            echo "</a>
                    </div>
                    ";
            // line 43
            if ($this->getAttribute($context["product"], "price", array())) {
                // line 44
                echo "                    <div class=\"price\">
                      ";
                // line 45
                if ($this->getAttribute($context["product"], "special", array())) {
                    // line 46
                    echo "                      <span class=\"sale\">";
                    echo $this->getAttribute($context["product"], "special", array());
                    echo "</span>
                      <span class=\"regular\">";
                    // line 47
                    echo $this->getAttribute($context["product"], "price", array());
                    echo "</span>
                      ";
                } else {
                    // line 49
                    echo "                      <span class=\"sale\">";
                    echo $this->getAttribute($context["product"], "price", array());
                    echo "</span>
                      ";
                }
                // line 51
                echo "                    </div>
                    ";
            }
            // line 53
            echo "                  </div><!-- /.box-content -->
                  <div class=\"box-bottom\">
                    <div class=\"btn-add-cart\">
                      <button class=\"btn btn-success\" type=\"button\" data-toggle=\"tooltip\" title=\"";
            // line 56
            echo (isset($context["button_cart"]) ? $context["button_cart"] : null);
            echo "\" onclick=\"cart.add('";
            echo $this->getAttribute($context["product"], "product_id", array());
            echo "');\"><img src=\"image/catalog/icons/add-cart.png\" alt=\"";
            echo (isset($context["button_cart"]) ? $context["button_cart"] : null);
            echo "\">";
            echo (isset($context["button_cart"]) ? $context["button_cart"] : null);
            echo "</button>
                      ";
            // line 58
            echo "                        ";
            // line 59
            echo "                      ";
            // line 60
            echo "                    </div>
                    <div class=\"compare-wishlist\">
                      <a href=\"#\" class=\"compare\" title=\"";
            // line 62
            echo (isset($context["button_compare"]) ? $context["button_compare"] : null);
            echo "\" onclick=\"compare.add('";
            echo $this->getAttribute($context["product"], "product_id", array());
            echo "');\">
                        <img src=\"image/catalog/icons/compare.png\" alt=\"";
            // line 63
            echo (isset($context["button_compare"]) ? $context["button_compare"] : null);
            echo "\">";
            echo (isset($context["button_compare"]) ? $context["button_compare"] : null);
            echo "
                      </a>
                      <a href=\"#\" class=\"wishlist\" title=\"";
            // line 65
            echo (isset($context["button_wishlist"]) ? $context["button_wishlist"] : null);
            echo "\" onclick=\"wishlist.add('";
            echo $this->getAttribute($context["product"], "product_id", array());
            echo "');\">
                        <img src=\"image/catalog/icons/wishlist.png\" alt=\"";
            // line 66
            echo (isset($context["button_wishlist"]) ? $context["button_wishlist"] : null);
            echo "\">";
            echo (isset($context["button_wishlist"]) ? $context["button_wishlist"] : null);
            echo "
                      </a>
                    </div>
                  </div><!-- /.box-bottom -->
                </div><!-- /.imagebox -->
              </div> 
            </div><!-- /.col-lg-3 col-sm-6 -->
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 74
        echo "
            </div><!-- /.row -->
        </div><!-- /.box-product -->
      </div><!-- /.container -->
    </section><!-- /.flat-imagebox -->";
    }

    public function getTemplateName()
    {
        return "default/template/extension/module/bestseller.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  192 => 74,  176 => 66,  170 => 65,  163 => 63,  157 => 62,  153 => 60,  151 => 59,  149 => 58,  139 => 56,  134 => 53,  130 => 51,  124 => 49,  119 => 47,  114 => 46,  112 => 45,  109 => 44,  107 => 43,  98 => 41,  94 => 39,  83 => 32,  77 => 31,  73 => 29,  69 => 27,  67 => 26,  59 => 22,  55 => 21,  52 => 20,  49 => 19,  46 => 18,  43 => 17,  40 => 16,  38 => 15,  27 => 7,  19 => 1,);
    }
}
/*     <section class="flat-imagebox bestsellerproducts">*/
/*       <div class="container1">*/
/*         <div class="row">*/
/*           <div class="col-md-12">*/
/*             <div class="product-tab">*/
/*               <ul class="tab-list">*/
/*                 <li class="active">{{ heading_title }}</li>*/
/*               </ul>*/
/*             </div><!-- /.product-tab -->*/
/*           </div><!-- /.col-md-12 -->*/
/*         </div><!-- /.row -->*/
/*         <div class="box-product">*/
/*           <div class="row">*/
/* */
/*               {% if setting.limit==3 %}*/
/*                   {% set class = 'col-lg-4 col-sm-6' %}*/
/*               {% else %}*/
/*                   {% set class = 'col-lg-3 col-sm-6' %}*/
/*               {% endif %}*/
/* */
/*               {% for product in products %}*/
/*                 <div class="{{ class }}">*/
/*               <div class="product-box">*/
/*                 <div class="imagebox">*/
/*                   <!--span class="item-new">NEW</span-->*/
/*                   {% if product.special %}*/
/*                   <span class="item-sale">SALE</span>*/
/*                   {% endif %}*/
/*                    <ul class="box-image owl-carousel-1">*/
/*                     <li>*/
/*                       <a href="{{ product.href }}" title="{{ product.name }}">*/
/*                         <img src="{{ product.thumb }}" alt="{{ product.name }}">*/
/*                       </a>*/
/*                     </li>*/
/*                   </ul><!-- /.box-image -->*/
/*                   <div class="box-content">*/
/*                     <div class="cat-name">*/
/*                       {#<a href="{{ product.href }}" title="">Laptops</a>#}*/
/*                     </div>*/
/*                     <div class="product-name">*/
/*                       <a href="{{ product.href }}" title="{{ product.name }}">{{ product.name }}</a>*/
/*                     </div>*/
/*                     {% if product.price %}*/
/*                     <div class="price">*/
/*                       {% if product.special %}*/
/*                       <span class="sale">{{ product.special }}</span>*/
/*                       <span class="regular">{{ product.price }}</span>*/
/*                       {% else %}*/
/*                       <span class="sale">{{ product.price }}</span>*/
/*                       {% endif %}*/
/*                     </div>*/
/*                     {% endif %}*/
/*                   </div><!-- /.box-content -->*/
/*                   <div class="box-bottom">*/
/*                     <div class="btn-add-cart">*/
/*                       <button class="btn btn-success" type="button" data-toggle="tooltip" title="{{ button_cart }}" onclick="cart.add('{{ product.product_id }}');"><img src="image/catalog/icons/add-cart.png" alt="{{ button_cart }}">{{ button_cart }}</button>*/
/*                       {#<a href="#" title="" onclick="cart.add('{{ product.product_id }}');">#}*/
/*                         {#<img src="image/catalog/icons/add-cart.png" alt="">{{ button_cart }}#}*/
/*                       {#</a>#}*/
/*                     </div>*/
/*                     <div class="compare-wishlist">*/
/*                       <a href="#" class="compare" title="{{ button_compare }}" onclick="compare.add('{{ product.product_id }}');">*/
/*                         <img src="image/catalog/icons/compare.png" alt="{{ button_compare }}">{{ button_compare }}*/
/*                       </a>*/
/*                       <a href="#" class="wishlist" title="{{ button_wishlist }}" onclick="wishlist.add('{{ product.product_id }}');">*/
/*                         <img src="image/catalog/icons/wishlist.png" alt="{{ button_wishlist }}">{{ button_wishlist }}*/
/*                       </a>*/
/*                     </div>*/
/*                   </div><!-- /.box-bottom -->*/
/*                 </div><!-- /.imagebox -->*/
/*               </div> */
/*             </div><!-- /.col-lg-3 col-sm-6 -->*/
/*             {% endfor %}*/
/* */
/*             </div><!-- /.row -->*/
/*         </div><!-- /.box-product -->*/
/*       </div><!-- /.container -->*/
/*     </section><!-- /.flat-imagebox -->*/
