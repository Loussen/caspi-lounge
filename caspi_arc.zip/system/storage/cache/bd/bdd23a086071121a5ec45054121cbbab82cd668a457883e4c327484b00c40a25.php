<?php

/* default/template/common/column_right.twig */
class __TwigTemplate_134b0898deda10f1cc7c90b6101795e3b543405b5b3bd080becf7a2d6b47c76e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        if ((isset($context["modules"]) ? $context["modules"] : null)) {
            // line 2
            echo "<div class=\"col-lg-3 col-md-4 hidden-md-down\">
    <div class=\"sidebar sidebar-right\">
        ";
            // line 4
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["modules"]) ? $context["modules"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["module"]) {
                // line 5
                echo "            ";
                echo $context["module"];
                echo "
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['module'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 7
            echo "    </div><!-- /.sidebar -->
</div><!-- /.col-lg-3 col-md-4 -->
";
        }
    }

    public function getTemplateName()
    {
        return "default/template/common/column_right.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 7,  29 => 5,  25 => 4,  21 => 2,  19 => 1,);
    }
}
/* {% if modules %}*/
/* <div class="col-lg-3 col-md-4 hidden-md-down">*/
/*     <div class="sidebar sidebar-right">*/
/*         {% for module in modules %}*/
/*             {{ module }}*/
/*         {% endfor %}*/
/*     </div><!-- /.sidebar -->*/
/* </div><!-- /.col-lg-3 col-md-4 -->*/
/* {% endif %}*/
/* */
