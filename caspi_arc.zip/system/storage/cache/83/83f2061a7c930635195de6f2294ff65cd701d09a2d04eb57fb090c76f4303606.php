<?php

/* default/template/common/menu.twig */
class __TwigTemplate_7be2b80e37b35d2a8f855bfff51bba3021e55bb81b754e241f59217b468e1084 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        if ((isset($context["categories"]) ? $context["categories"] : null)) {
            // line 2
            echo "<div id=\"mega-menu\">
  <div class=\"btn-mega\"><span></span>";
            // line 3
            echo (isset($context["text_category"]) ? $context["text_category"] : null);
            echo "</div>
  <ul class=\"menu\">
    ";
            // line 5
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
                // line 6
                echo "    <li>
      <a href=\"";
                // line 7
                echo $this->getAttribute($context["category"], "href", array());
                echo "\" title=\"\"";
                if ($this->getAttribute($context["category"], "children", array())) {
                    echo " class=\"dropdown\"";
                }
                echo ">
        <span class=\"menu-img\">
          <img src=\"catalog/view/theme/default/images/icons/menu/01.png\" alt=\"\">
        </span>
        <span class=\"menu-title\">
          ";
                // line 12
                echo $this->getAttribute($context["category"], "name", array());
                echo "
        </span>
      </a>
      ";
                // line 15
                if ($this->getAttribute($context["category"], "children", array())) {
                    // line 16
                    echo "      <div class=\"drop-menu\">
        <div class=\"one-third\">
          <div class=\"cat-title\">
            ";
                    // line 19
                    echo $this->getAttribute($context["category"], "name", array());
                    echo "
          </div>
          <ul class=\"child row\">
            ";
                    // line 22
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["category"], "children", array()));
                    foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                        // line 23
                        echo "            <li class=\"col-sm-4\">
              <a href=\"";
                        // line 24
                        echo $this->getAttribute($context["child"], "href", array());
                        echo "\" title=\"\">";
                        echo $this->getAttribute($context["child"], "name", array());
                        echo "</a>
            </li>
            ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 27
                    echo "          </ul>
          <div class=\"show\">
            <a href=\"";
                    // line 29
                    echo $this->getAttribute($context["category"], "href", array());
                    echo "\" title=\"\">";
                    echo (isset($context["text_all"]) ? $context["text_all"] : null);
                    echo "</a>
          </div>
        </div>
      </div>
      ";
                }
                // line 34
                echo "    </li>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 36
            echo "  </ul>
</div>
";
        }
        // line 38
        echo " ";
    }

    public function getTemplateName()
    {
        return "default/template/common/menu.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  111 => 38,  106 => 36,  99 => 34,  89 => 29,  85 => 27,  74 => 24,  71 => 23,  67 => 22,  61 => 19,  56 => 16,  54 => 15,  48 => 12,  36 => 7,  33 => 6,  29 => 5,  24 => 3,  21 => 2,  19 => 1,);
    }
}
/* {% if categories %}*/
/* <div id="mega-menu">*/
/*   <div class="btn-mega"><span></span>{{ text_category }}</div>*/
/*   <ul class="menu">*/
/*     {% for category in categories %}*/
/*     <li>*/
/*       <a href="{{ category.href }}" title=""{% if category.children %} class="dropdown"{% endif %}>*/
/*         <span class="menu-img">*/
/*           <img src="catalog/view/theme/default/images/icons/menu/01.png" alt="">*/
/*         </span>*/
/*         <span class="menu-title">*/
/*           {{ category.name }}*/
/*         </span>*/
/*       </a>*/
/*       {% if category.children %}*/
/*       <div class="drop-menu">*/
/*         <div class="one-third">*/
/*           <div class="cat-title">*/
/*             {{ category.name }}*/
/*           </div>*/
/*           <ul class="child row">*/
/*             {% for child in category.children %}*/
/*             <li class="col-sm-4">*/
/*               <a href="{{ child.href }}" title="">{{ child.name }}</a>*/
/*             </li>*/
/*             {% endfor %}*/
/*           </ul>*/
/*           <div class="show">*/
/*             <a href="{{ category.href }}" title="">{{ text_all }}</a>*/
/*           </div>*/
/*         </div>*/
/*       </div>*/
/*       {% endif %}*/
/*     </li>*/
/*     {% endfor %}*/
/*   </ul>*/
/* </div>*/
/* {% endif %} */
