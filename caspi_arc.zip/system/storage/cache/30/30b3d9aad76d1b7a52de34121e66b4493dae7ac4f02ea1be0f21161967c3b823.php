<?php

/* default/template/common/header.twig */
class __TwigTemplate_9ed3d7f1f6fd1c5ca6f20ce547c6897322b078da7f672b78fc634200386ebd1c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<!--[if IE 8 ]><html dir=\"";
        // line 2
        echo (isset($context["direction"]) ? $context["direction"] : null);
        echo "\" lang=\"";
        echo (isset($context["lang"]) ? $context["lang"] : null);
        echo "\"><![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html dir=\"";
        // line 4
        echo (isset($context["direction"]) ? $context["direction"] : null);
        echo "\" lang=\"";
        echo (isset($context["lang"]) ? $context["lang"] : null);
        echo "\"><!--<![endif]-->
<head>
  <!-- Basic Page Needs -->
  <meta charset=\"UTF-8\">
  <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
  <title>";
        // line 9
        echo (isset($context["title"]) ? $context["title"] : null);
        echo "</title>
  <base href=\"";
        // line 10
        echo (isset($context["base"]) ? $context["base"] : null);
        echo "\" />
  ";
        // line 11
        if ((isset($context["description"]) ? $context["description"] : null)) {
            // line 12
            echo "    <meta name=\"description\" content=\"";
            echo (isset($context["description"]) ? $context["description"] : null);
            echo "\" />
  ";
        }
        // line 14
        echo "  ";
        if ((isset($context["keywords"]) ? $context["keywords"] : null)) {
            // line 15
            echo "    <meta name=\"keywords\" content=\"";
            echo (isset($context["keywords"]) ? $context["keywords"] : null);
            echo "\" />
  ";
        }
        // line 17
        echo "
  <meta name=\"author\" content=\"";
        // line 18
        echo (isset($context["author"]) ? $context["author"] : null);
        echo "\">

  <!-- Mobile Specific Metas -->
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\">

  <!-- Boostrap style -->
  <link rel=\"stylesheet\" type=\"text/css\" href=\"catalog/view/theme/default/stylesheet/bootstrap.min.css\">

  ";
        // line 26
        if (((isset($context["lang"]) ? $context["lang"] : null) == "az")) {
            // line 27
            echo "    <link rel=\"stylesheet\" type=\"text/css\" href=\"https://fonts.googleapis.com/css?family=Comfortaa:300,400,700&amp;subset=cyrillic,cyrillic-ext,latin-ext&text=%21%22%23%24%25%26%27%28%29%30+,-./0123456789:;%3C=%3E%3F@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`%E2%82%AC„‘’“”™©®°µ±÷abcdefghijklmnopqrstuvwxyz{|}~%C3%9C%C3%96%C4%9E%C4%B0%C6%8F%C3%87%C5%9E%C3%BC%C3%B6%C4%9F%C4%B1%C9%99%C3%A7%C5%9F\">
  ";
        } else {
            // line 29
            echo "    <link rel=\"stylesheet\" type=\"text/css\" href=\"https://fonts.googleapis.com/css?family=Comfortaa:300,400,700&amp;subset=cyrillic,cyrillic-ext,latin-ext\">
  ";
        }
        // line 31
        echo "

  <!-- Theme style -->
  <link rel=\"stylesheet\" type=\"text/css\" href=\"catalog/view/theme/default/stylesheet/style.css\">

  <!-- Reponsive -->
  <link rel=\"stylesheet\" type=\"text/css\" href=\"catalog/view/theme/default/stylesheet/responsive.css\">

  <link rel=\"shortcut icon\" href=\"catalog/view/theme/default/images/favicon.png\">

  ";
        // line 41
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["styles"]) ? $context["styles"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["style"]) {
            // line 42
            echo "    <link href=\"";
            echo $this->getAttribute($context["style"], "href", array());
            echo "\" type=\"text/css\" rel=\"";
            echo $this->getAttribute($context["style"], "rel", array());
            echo "\" media=\"";
            echo $this->getAttribute($context["style"], "media", array());
            echo "\" />
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['style'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        echo "
  ";
        // line 45
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["links"]) ? $context["links"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["link"]) {
            // line 46
            echo "    <link href=\"";
            echo $this->getAttribute($context["link"], "href", array());
            echo "\" rel=\"";
            echo $this->getAttribute($context["link"], "rel", array());
            echo "\" />
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['link'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "
  ";
        // line 49
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["analytics"]) ? $context["analytics"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["analytic"]) {
            // line 50
            echo "    ";
            echo $context["analytic"];
            echo "
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['analytic'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 52
        echo "
</head>
<body class=\"";
        // line 54
        echo (isset($context["body_class"]) ? $context["body_class"] : null);
        echo "\">


<div class=\"boxed\">

  <div class=\"overlay\"></div>


  <!-- Preloader -->
  <div class=\"preloader\">
    <div class=\"clear-loading loading-effect-2\">
      <span></span>
    </div>
  </div><!-- /.preloader -->



  <div id=\"alert-popups\" class=\"popup-newsletter\">
    <div class=\"container\">
      <div class=\"row\">
        <div class=\"col-sm-2\">

        </div>
        <div class=\"col-sm-8\">
          <div class=\"popup\">
            <span></span>
            <div class=\"popup-text\">

            </div>
          </div>
        </div>
        <div class=\"col-sm-2\">

        </div>
      </div>
    </div>
  </div>


  <section id=\"header\" class=\"header\">
    <div class=\"header-top\">
      <div class=\"container\">
        <div class=\"row\">
          <div class=\"col-md-3 hidden-md-down\">
            <ul class=\"flat-support text-center\">
              <li><a href=\"#\" title=\"\"><i class=\"fa fa-facebook\" aria-hidden=\"true\"></i></a></li>
              <li><a href=\"#\" title=\"\"><i class=\"fa fa-instagram\" aria-hidden=\"true\"></i></a></li>
              <li><a href=\"#\" title=\"\"><i class=\"fa fa-google\" aria-hidden=\"true\"></i></a></li>
              <li><a href=\"#\" title=\"\"><i class=\"fa fa-vk\" aria-hidden=\"true\"></i></a></li>
            </ul><!-- /.flat-support -->
          </div><!-- /.col-md-4 -->
          <div class=\"col-md-5 hidden-md-down\">
            <div class=\"row\">
              <div class=\"col-md-6\">
                <ul class=\"flat-infomation\">
                  <li class=\"phone\">
                    <i class=\"fa fa-phone\"></i> <a href=\"";
        // line 110
        echo (isset($context["contact"]) ? $context["contact"] : null);
        echo "\" title=\"\">";
        echo (isset($context["telephone"]) ? $context["telephone"] : null);
        echo "</a>
                  </li>
                </ul><!-- /.flat-infomation -->
              </div><!-- /.col-md-6 -->
              <div class=\"col-md-6\">
                <ul class=\"flat-infomation\">
                  <li class=\"phone\">
                    <i class=\"fa fa-phone\"></i> <a href=\"";
        // line 117
        echo (isset($context["contact"]) ? $context["contact"] : null);
        echo "\" title=\"\">+994 (12) 555-16-26<!--";
        echo (isset($context["header_email"]) ? $context["header_email"] : null);
        echo "--></a>
                  </li>
                </ul><!-- /.flat-infomation -->
              </div><!-- /.col-md-6 -->
            </div>
          </div>
          <div class=\"col-md-4\">
            <ul class=\"flat-unstyled\">
              <li class=\"account\">
                <a href=\"";
        // line 126
        echo (isset($context["account"]) ? $context["account"] : null);
        echo "\" title=\"\" class=\"dropdown-toggle1\" data-toggle=\"dropdown\">";
        echo (isset($context["text_account"]) ? $context["text_account"] : null);
        echo "<i class=\"fa fa-angle-down\" aria-hidden=\"true\"></i></a>
                <ul class=\"unstyled\">

                  ";
        // line 129
        if ((isset($context["logged"]) ? $context["logged"] : null)) {
            // line 130
            echo "                    <li><a href=\"";
            echo (isset($context["account"]) ? $context["account"] : null);
            echo "\">";
            echo (isset($context["text_account"]) ? $context["text_account"] : null);
            echo "</a></li>
                    <li><a href=\"";
            // line 131
            echo (isset($context["order"]) ? $context["order"] : null);
            echo "\">";
            echo (isset($context["text_order"]) ? $context["text_order"] : null);
            echo "</a></li>
                    <li><a href=\"";
            // line 132
            echo (isset($context["transaction"]) ? $context["transaction"] : null);
            echo "\">";
            echo (isset($context["text_transaction"]) ? $context["text_transaction"] : null);
            echo "</a></li>
                    <li><a href=\"";
            // line 133
            echo (isset($context["download"]) ? $context["download"] : null);
            echo "\">";
            echo (isset($context["text_download"]) ? $context["text_download"] : null);
            echo "</a></li>
                    <li><a href=\"";
            // line 134
            echo (isset($context["logout"]) ? $context["logout"] : null);
            echo "\">";
            echo (isset($context["text_logout"]) ? $context["text_logout"] : null);
            echo "</a></li>
                  ";
        } else {
            // line 136
            echo "                    <li><a href=\"";
            echo (isset($context["register"]) ? $context["register"] : null);
            echo "\">";
            echo (isset($context["text_register"]) ? $context["text_register"] : null);
            echo "</a></li>
                    <li><a href=\"";
            // line 137
            echo (isset($context["login"]) ? $context["login"] : null);
            echo "\">";
            echo (isset($context["text_login"]) ? $context["text_login"] : null);
            echo "</a></li>
                  ";
        }
        // line 139
        echo "
                </ul><!-- /.unstyled -->
              </li>


              ";
        // line 144
        echo (isset($context["currency"]) ? $context["currency"] : null);
        echo "
              ";
        // line 145
        echo (isset($context["language"]) ? $context["language"] : null);
        echo "


            </ul><!-- /.flat-unstyled -->
          </div><!-- /.col-md-4 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </div><!-- /.header-top -->
    <div class=\"header-middle\">
      <div class=\"container\">
        <div class=\"row\">
          <div class=\"col-md-3\">

            <div id=\"logo\" class=\"logo\">
              ";
        // line 159
        if ((isset($context["logo"]) ? $context["logo"] : null)) {
            // line 160
            echo "                <a href=\"";
            echo (isset($context["home"]) ? $context["home"] : null);
            echo "\" title=\"";
            echo (isset($context["name"]) ? $context["name"] : null);
            echo "\" ><img src=\"catalog/view/theme/default/images/logos/logo.svg\" alt=\"";
            echo (isset($context["name"]) ? $context["name"] : null);
            echo "\" /></a>
              ";
        } else {
            // line 162
            echo "                <a href=\"";
            echo (isset($context["home"]) ? $context["home"] : null);
            echo "\">";
            echo (isset($context["name"]) ? $context["name"] : null);
            echo "</a>
              ";
        }
        // line 164
        echo "            </div><!-- /#logo -->

            <div id=\"search_open_button\" class=\"hidden-md-up\">
              <button type=\"button\" data-loading-text=\"";
        // line 167
        echo (isset($context["text_search"]) ? $context["text_search"] : null);
        echo "\" class=\"btn btn-inverse btn-block btn-lg\">
                <img src=\"catalog/view/theme/default/images/icons/search.png\" alt=\"\">
              </button>
            </div>

          </div><!-- /.col-md-3 -->
          <div class=\"col-md-6\">

            ";
        // line 175
        echo (isset($context["search"]) ? $context["search"] : null);
        echo "

          </div><!-- /.col-md-6 -->
          <div class=\"col-md-3\">
            <div class=\"box-cart\">
              ";
        // line 181
        echo "              ";
        // line 182
        echo "              ";
        // line 183
        echo "              ";
        // line 184
        echo "              ";
        // line 185
        echo "              ";
        // line 186
        echo "              ";
        // line 187
        echo "              ";
        // line 188
        echo "              ";
        // line 189
        echo "              ";
        // line 190
        echo "              ";
        // line 191
        echo "              ";
        // line 192
        echo "              ";
        // line 193
        echo "              ";
        // line 194
        echo "

              ";
        // line 196
        echo (isset($context["cart"]) ? $context["cart"] : null);
        echo "



            </div><!-- /.box-cart -->
          </div><!-- /.col-md-3 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </div><!-- /.header-middle -->
    <div class=\"header-bottom clearfix\">
      <div class=\"container\">
        <div class=\"row\">
          <div class=\"col-md-3 col-2\">

            ";
        // line 210
        echo (isset($context["menu"]) ? $context["menu"] : null);
        echo "

          </div><!-- /.col-md-3 -->
          <div class=\"col-md-9 col-10\">
            <div class=\"nav-wrap\">
              <div id=\"mainnav\" class=\"mainnav\">
                <ul class=\"menu\">

                  <li class=\"column-1\"><a href=\"";
        // line 218
        echo (isset($context["home"]) ? $context["home"] : null);
        echo "\">";
        echo (isset($context["text_home"]) ? $context["text_home"] : null);
        echo "</a></li>
                  <li class=\"column-1\"><a href=\"";
        // line 219
        echo (isset($context["about"]) ? $context["about"] : null);
        echo "\">";
        echo (isset($context["text_about"]) ? $context["text_about"] : null);
        echo "</a></li>
                  <li class=\"column-1\"><a href=\"";
        // line 220
        echo (isset($context["delivery"]) ? $context["delivery"] : null);
        echo "\">";
        echo (isset($context["text_delivery"]) ? $context["text_delivery"] : null);
        echo "</a></li>
                  <li class=\"column-1\"><a href=\"";
        // line 221
        echo (isset($context["payment"]) ? $context["payment"] : null);
        echo "\">";
        echo (isset($context["text_payment"]) ? $context["text_payment"] : null);
        echo "</a></li>
                  <li class=\"column-1\"><a href=\"";
        // line 222
        echo (isset($context["services"]) ? $context["services"] : null);
        echo "\">";
        echo (isset($context["text_services"]) ? $context["text_services"] : null);
        echo "</a></li>
                  <li class=\"column-1\"><a href=\"";
        // line 223
        echo (isset($context["manufacturer"]) ? $context["manufacturer"] : null);
        echo "\">";
        echo (isset($context["text_manufacturer"]) ? $context["text_manufacturer"] : null);
        echo "</a></li>
                  <li class=\"column-1\"><a href=\"";
        // line 224
        echo (isset($context["special"]) ? $context["special"] : null);
        echo "\">";
        echo (isset($context["text_special"]) ? $context["text_special"] : null);
        echo "</a></li>
                  <li class=\"column-1\"><a href=\"";
        // line 225
        echo (isset($context["contact"]) ? $context["contact"] : null);
        echo "\">";
        echo (isset($context["text_contact"]) ? $context["text_contact"] : null);
        echo "</a></li>

                </ul><!-- /.menu -->
              </div><!-- /.mainnav -->
            </div><!-- /.nav-wrap -->


            <div class=\"btn-menu\">
              <span></span>
            </div><!-- //mobile menu button -->
          </div><!-- /.col-md-9 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </div><!-- /.header-bottom -->
  </section><!-- /#header -->";
    }

    public function getTemplateName()
    {
        return "default/template/common/header.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  468 => 225,  462 => 224,  456 => 223,  450 => 222,  444 => 221,  438 => 220,  432 => 219,  426 => 218,  415 => 210,  398 => 196,  394 => 194,  392 => 193,  390 => 192,  388 => 191,  386 => 190,  384 => 189,  382 => 188,  380 => 187,  378 => 186,  376 => 185,  374 => 184,  372 => 183,  370 => 182,  368 => 181,  360 => 175,  349 => 167,  344 => 164,  336 => 162,  326 => 160,  324 => 159,  307 => 145,  303 => 144,  296 => 139,  289 => 137,  282 => 136,  275 => 134,  269 => 133,  263 => 132,  257 => 131,  250 => 130,  248 => 129,  240 => 126,  226 => 117,  214 => 110,  155 => 54,  151 => 52,  142 => 50,  138 => 49,  135 => 48,  124 => 46,  120 => 45,  117 => 44,  104 => 42,  100 => 41,  88 => 31,  84 => 29,  80 => 27,  78 => 26,  67 => 18,  64 => 17,  58 => 15,  55 => 14,  49 => 12,  47 => 11,  43 => 10,  39 => 9,  29 => 4,  22 => 2,  19 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <!--[if IE 8 ]><html dir="{{ direction }}" lang="{{ lang }}"><![endif]-->*/
/* <!--[if (gte IE 9)|!(IE)]><!-->*/
/* <html dir="{{ direction }}" lang="{{ lang }}"><!--<![endif]-->*/
/* <head>*/
/*   <!-- Basic Page Needs -->*/
/*   <meta charset="UTF-8">*/
/*   <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->*/
/*   <title>{{ title }}</title>*/
/*   <base href="{{ base }}" />*/
/*   {% if description %}*/
/*     <meta name="description" content="{{ description }}" />*/
/*   {% endif %}*/
/*   {% if keywords %}*/
/*     <meta name="keywords" content="{{ keywords }}" />*/
/*   {% endif %}*/
/* */
/*   <meta name="author" content="{{ author }}">*/
/* */
/*   <!-- Mobile Specific Metas -->*/
/*   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">*/
/* */
/*   <!-- Boostrap style -->*/
/*   <link rel="stylesheet" type="text/css" href="catalog/view/theme/default/stylesheet/bootstrap.min.css">*/
/* */
/*   {% if lang == "az" %}*/
/*     <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Comfortaa:300,400,700&amp;subset=cyrillic,cyrillic-ext,latin-ext&text=%21%22%23%24%25%26%27%28%29%30+,-./0123456789:;%3C=%3E%3F@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`%E2%82%AC„‘’“”™©®°µ±÷abcdefghijklmnopqrstuvwxyz{|}~%C3%9C%C3%96%C4%9E%C4%B0%C6%8F%C3%87%C5%9E%C3%BC%C3%B6%C4%9F%C4%B1%C9%99%C3%A7%C5%9F">*/
/*   {% else %}*/
/*     <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Comfortaa:300,400,700&amp;subset=cyrillic,cyrillic-ext,latin-ext">*/
/*   {% endif %}*/
/* */
/* */
/*   <!-- Theme style -->*/
/*   <link rel="stylesheet" type="text/css" href="catalog/view/theme/default/stylesheet/style.css">*/
/* */
/*   <!-- Reponsive -->*/
/*   <link rel="stylesheet" type="text/css" href="catalog/view/theme/default/stylesheet/responsive.css">*/
/* */
/*   <link rel="shortcut icon" href="catalog/view/theme/default/images/favicon.png">*/
/* */
/*   {% for style in styles %}*/
/*     <link href="{{ style.href }}" type="text/css" rel="{{ style.rel }}" media="{{ style.media }}" />*/
/*   {% endfor %}*/
/* */
/*   {% for link in links %}*/
/*     <link href="{{ link.href }}" rel="{{ link.rel }}" />*/
/*   {% endfor %}*/
/* */
/*   {% for analytic in analytics %}*/
/*     {{ analytic }}*/
/*   {% endfor %}*/
/* */
/* </head>*/
/* <body class="{{ body_class }}">*/
/* */
/* */
/* <div class="boxed">*/
/* */
/*   <div class="overlay"></div>*/
/* */
/* */
/*   <!-- Preloader -->*/
/*   <div class="preloader">*/
/*     <div class="clear-loading loading-effect-2">*/
/*       <span></span>*/
/*     </div>*/
/*   </div><!-- /.preloader -->*/
/* */
/* */
/* */
/*   <div id="alert-popups" class="popup-newsletter">*/
/*     <div class="container">*/
/*       <div class="row">*/
/*         <div class="col-sm-2">*/
/* */
/*         </div>*/
/*         <div class="col-sm-8">*/
/*           <div class="popup">*/
/*             <span></span>*/
/*             <div class="popup-text">*/
/* */
/*             </div>*/
/*           </div>*/
/*         </div>*/
/*         <div class="col-sm-2">*/
/* */
/*         </div>*/
/*       </div>*/
/*     </div>*/
/*   </div>*/
/* */
/* */
/*   <section id="header" class="header">*/
/*     <div class="header-top">*/
/*       <div class="container">*/
/*         <div class="row">*/
/*           <div class="col-md-3 hidden-md-down">*/
/*             <ul class="flat-support text-center">*/
/*               <li><a href="#" title=""><i class="fa fa-facebook" aria-hidden="true"></i></a></li>*/
/*               <li><a href="#" title=""><i class="fa fa-instagram" aria-hidden="true"></i></a></li>*/
/*               <li><a href="#" title=""><i class="fa fa-google" aria-hidden="true"></i></a></li>*/
/*               <li><a href="#" title=""><i class="fa fa-vk" aria-hidden="true"></i></a></li>*/
/*             </ul><!-- /.flat-support -->*/
/*           </div><!-- /.col-md-4 -->*/
/*           <div class="col-md-5 hidden-md-down">*/
/*             <div class="row">*/
/*               <div class="col-md-6">*/
/*                 <ul class="flat-infomation">*/
/*                   <li class="phone">*/
/*                     <i class="fa fa-phone"></i> <a href="{{contact}}" title="">{{ telephone }}</a>*/
/*                   </li>*/
/*                 </ul><!-- /.flat-infomation -->*/
/*               </div><!-- /.col-md-6 -->*/
/*               <div class="col-md-6">*/
/*                 <ul class="flat-infomation">*/
/*                   <li class="phone">*/
/*                     <i class="fa fa-phone"></i> <a href="{{contact}}" title="">+994 (12) 555-16-26<!--{{ header_email }}--></a>*/
/*                   </li>*/
/*                 </ul><!-- /.flat-infomation -->*/
/*               </div><!-- /.col-md-6 -->*/
/*             </div>*/
/*           </div>*/
/*           <div class="col-md-4">*/
/*             <ul class="flat-unstyled">*/
/*               <li class="account">*/
/*                 <a href="{{ account }}" title="" class="dropdown-toggle1" data-toggle="dropdown">{{ text_account }}<i class="fa fa-angle-down" aria-hidden="true"></i></a>*/
/*                 <ul class="unstyled">*/
/* */
/*                   {% if logged %}*/
/*                     <li><a href="{{ account }}">{{ text_account }}</a></li>*/
/*                     <li><a href="{{ order }}">{{ text_order }}</a></li>*/
/*                     <li><a href="{{ transaction }}">{{ text_transaction }}</a></li>*/
/*                     <li><a href="{{ download }}">{{ text_download }}</a></li>*/
/*                     <li><a href="{{ logout }}">{{ text_logout }}</a></li>*/
/*                   {% else %}*/
/*                     <li><a href="{{ register }}">{{ text_register }}</a></li>*/
/*                     <li><a href="{{ login }}">{{ text_login }}</a></li>*/
/*                   {% endif %}*/
/* */
/*                 </ul><!-- /.unstyled -->*/
/*               </li>*/
/* */
/* */
/*               {{ currency }}*/
/*               {{ language }}*/
/* */
/* */
/*             </ul><!-- /.flat-unstyled -->*/
/*           </div><!-- /.col-md-4 -->*/
/*         </div><!-- /.row -->*/
/*       </div><!-- /.container -->*/
/*     </div><!-- /.header-top -->*/
/*     <div class="header-middle">*/
/*       <div class="container">*/
/*         <div class="row">*/
/*           <div class="col-md-3">*/
/* */
/*             <div id="logo" class="logo">*/
/*               {% if logo %}*/
/*                 <a href="{{ home }}" title="{{ name }}" ><img src="catalog/view/theme/default/images/logos/logo.svg" alt="{{ name }}" /></a>*/
/*               {% else %}*/
/*                 <a href="{{ home }}">{{ name }}</a>*/
/*               {% endif %}*/
/*             </div><!-- /#logo -->*/
/* */
/*             <div id="search_open_button" class="hidden-md-up">*/
/*               <button type="button" data-loading-text="{{ text_search }}" class="btn btn-inverse btn-block btn-lg">*/
/*                 <img src="catalog/view/theme/default/images/icons/search.png" alt="">*/
/*               </button>*/
/*             </div>*/
/* */
/*           </div><!-- /.col-md-3 -->*/
/*           <div class="col-md-6">*/
/* */
/*             {{ search }}*/
/* */
/*           </div><!-- /.col-md-6 -->*/
/*           <div class="col-md-3">*/
/*             <div class="box-cart">*/
/*               {#<div class="inner-box">#}*/
/*               {#<ul class="menu-compare-wishlist">#}*/
/*               {#<li class="compare">#}*/
/*               {#<a href="{{ compare }}" title="{{ text_compare }}">#}*/
/*               {#<img src="catalog/view/theme/default/images/icons/compare.png" alt="">#}*/
/*               {#</a>#}*/
/*               {#</li>#}*/
/*               {#<li class="wishlist">#}*/
/*               {#<a href="{{ wishlist }}" title="{{ text_wishlist }}">#}*/
/*               {#<img src="catalog/view/theme/default/images/icons/wishlist.png" alt="">#}*/
/*               {#</a>#}*/
/*               {#</li>#}*/
/*               {#</ul><!-- /.menu-compare-wishlist -->#}*/
/*               {#</div><!-- /.inner-box -->#}*/
/* */
/* */
/*               {{ cart }}*/
/* */
/* */
/* */
/*             </div><!-- /.box-cart -->*/
/*           </div><!-- /.col-md-3 -->*/
/*         </div><!-- /.row -->*/
/*       </div><!-- /.container -->*/
/*     </div><!-- /.header-middle -->*/
/*     <div class="header-bottom clearfix">*/
/*       <div class="container">*/
/*         <div class="row">*/
/*           <div class="col-md-3 col-2">*/
/* */
/*             {{ menu }}*/
/* */
/*           </div><!-- /.col-md-3 -->*/
/*           <div class="col-md-9 col-10">*/
/*             <div class="nav-wrap">*/
/*               <div id="mainnav" class="mainnav">*/
/*                 <ul class="menu">*/
/* */
/*                   <li class="column-1"><a href="{{home}}">{{text_home}}</a></li>*/
/*                   <li class="column-1"><a href="{{about}}">{{text_about}}</a></li>*/
/*                   <li class="column-1"><a href="{{delivery}}">{{text_delivery}}</a></li>*/
/*                   <li class="column-1"><a href="{{payment}}">{{text_payment}}</a></li>*/
/*                   <li class="column-1"><a href="{{services}}">{{text_services}}</a></li>*/
/*                   <li class="column-1"><a href="{{ manufacturer }}">{{text_manufacturer}}</a></li>*/
/*                   <li class="column-1"><a href="{{special}}">{{text_special}}</a></li>*/
/*                   <li class="column-1"><a href="{{contact}}">{{text_contact}}</a></li>*/
/* */
/*                 </ul><!-- /.menu -->*/
/*               </div><!-- /.mainnav -->*/
/*             </div><!-- /.nav-wrap -->*/
/* */
/* */
/*             <div class="btn-menu">*/
/*               <span></span>*/
/*             </div><!-- //mobile menu button -->*/
/*           </div><!-- /.col-md-9 -->*/
/*         </div><!-- /.row -->*/
/*       </div><!-- /.container -->*/
/*     </div><!-- /.header-bottom -->*/
/*   </section><!-- /#header -->*/
