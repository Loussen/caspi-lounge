<?php

/* default/template/common/cart.twig */
class __TwigTemplate_1654965774bb601088e68f864153f26d35013edc4a18be079cb0ee0905256663 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"inner-box\" id=\"cart\">
  <button type=\"button\" data-toggle=\"dropdown\" data-loading-text=\"";
        // line 2
        echo (isset($context["text_loading"]) ? $context["text_loading"] : null);
        echo "\" class=\"btn btn-inverse btn-block btn-lg dropdown-toggle\">
      ";
        // line 3
        echo (isset($context["text_items"]) ? $context["text_items"] : null);
        echo "
  </button>
  ";
        // line 6
        echo "    ";
        // line 7
        echo "  ";
        // line 8
        echo "  <div class=\"dropdown-box\">
    <div class=\"dropdown-content\">

      ";
        // line 11
        if (((isset($context["products"]) ? $context["products"] : null) || (isset($context["vouchers"]) ? $context["vouchers"] : null))) {
            // line 12
            echo "      <ul>

        ";
            // line 14
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["products"]) ? $context["products"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
                // line 15
                echo "        <li>
          <a href=\"";
                // line 16
                echo $this->getAttribute($context["product"], "href", array());
                echo "\">
            <div class=\"img-product\">
              <img src=\"";
                // line 18
                echo $this->getAttribute($context["product"], "thumb", array());
                echo "\" alt=\"";
                echo $this->getAttribute($context["product"], "name", array());
                echo "\">
            </div>
            <div class=\"info-product\">
              <div class=\"name\">
                ";
                // line 22
                echo $this->getAttribute($context["product"], "name", array());
                echo "
              </div>
              <div class=\"price\">
                <span>";
                // line 25
                echo $this->getAttribute($context["product"], "quantity", array());
                echo " x</span>
                <span>";
                // line 26
                echo $this->getAttribute($context["product"], "total", array());
                echo "</span>
              </div>
            </div>
            <div class=\"clearfix\"></div>
          </a>
          <span class=\"delete\" onclick=\"cart.remove('";
                // line 31
                echo $this->getAttribute($context["product"], "cart_id", array());
                echo "');\" data-toggle=\"tooltip\" title=\"";
                echo (isset($context["button_remove"]) ? $context["button_remove"] : null);
                echo "\"><img src=\"catalog/view/theme/default/images/icons/delete.png\" alt=\"\"></span>
        </li>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 34
            echo "
      </ul>


      ";
            // line 38
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["totals"]) ? $context["totals"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["total"]) {
                // line 39
                echo "      <div class=\"total\">
        <span>";
                // line 40
                echo $this->getAttribute($context["total"], "title", array());
                echo "</span>
        <span class=\"price\">";
                // line 41
                echo $this->getAttribute($context["total"], "text", array());
                echo "</span>
      </div>
      ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['total'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 44
            echo "
      <div class=\"btn-cart\">
        <a href=\"";
            // line 46
            echo (isset($context["cart"]) ? $context["cart"] : null);
            echo "\" class=\"view-cart\" title=\"\">";
            echo (isset($context["text_cart"]) ? $context["text_cart"] : null);
            echo "</a>
        <a href=\"";
            // line 47
            echo (isset($context["checkout"]) ? $context["checkout"] : null);
            echo "\" class=\"check-out\" title=\"\">";
            echo (isset($context["text_checkout"]) ? $context["text_checkout"] : null);
            echo "</a>
      </div>

      ";
        } else {
            // line 51
            echo "      <div class=\"text-center\">";
            echo (isset($context["text_empty"]) ? $context["text_empty"] : null);
            echo "</div>
      ";
        }
        // line 53
        echo "
    </div>
  </div>
</div><!-- /.inner-box -->";
    }

    public function getTemplateName()
    {
        return "default/template/common/cart.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 53,  141 => 51,  132 => 47,  126 => 46,  122 => 44,  113 => 41,  109 => 40,  106 => 39,  102 => 38,  96 => 34,  85 => 31,  77 => 26,  73 => 25,  67 => 22,  58 => 18,  53 => 16,  50 => 15,  46 => 14,  42 => 12,  40 => 11,  35 => 8,  33 => 7,  31 => 6,  26 => 3,  22 => 2,  19 => 1,);
    }
}
/* <div class="inner-box" id="cart">*/
/*   <button type="button" data-toggle="dropdown" data-loading-text="{{ text_loading }}" class="btn btn-inverse btn-block btn-lg dropdown-toggle">*/
/*       {{ text_items }}*/
/*   </button>*/
/*   {#<a href="#" title="" data-toggle="dropdown" data-loading-text="{{ text_loading }}">#}*/
/*     {#{{ text_items }}#}*/
/*   {#</a>#}*/
/*   <div class="dropdown-box">*/
/*     <div class="dropdown-content">*/
/* */
/*       {% if products or vouchers %}*/
/*       <ul>*/
/* */
/*         {% for product in products %}*/
/*         <li>*/
/*           <a href="{{ product.href }}">*/
/*             <div class="img-product">*/
/*               <img src="{{ product.thumb }}" alt="{{ product.name }}">*/
/*             </div>*/
/*             <div class="info-product">*/
/*               <div class="name">*/
/*                 {{ product.name }}*/
/*               </div>*/
/*               <div class="price">*/
/*                 <span>{{ product.quantity }} x</span>*/
/*                 <span>{{ product.total }}</span>*/
/*               </div>*/
/*             </div>*/
/*             <div class="clearfix"></div>*/
/*           </a>*/
/*           <span class="delete" onclick="cart.remove('{{ product.cart_id }}');" data-toggle="tooltip" title="{{ button_remove }}"><img src="catalog/view/theme/default/images/icons/delete.png" alt=""></span>*/
/*         </li>*/
/*         {% endfor %}*/
/* */
/*       </ul>*/
/* */
/* */
/*       {% for total in totals %}*/
/*       <div class="total">*/
/*         <span>{{ total.title }}</span>*/
/*         <span class="price">{{ total.text }}</span>*/
/*       </div>*/
/*       {% endfor %}*/
/* */
/*       <div class="btn-cart">*/
/*         <a href="{{ cart }}" class="view-cart" title="">{{ text_cart }}</a>*/
/*         <a href="{{ checkout }}" class="check-out" title="">{{ text_checkout }}</a>*/
/*       </div>*/
/* */
/*       {% else %}*/
/*       <div class="text-center">{{ text_empty }}</div>*/
/*       {% endif %}*/
/* */
/*     </div>*/
/*   </div>*/
/* </div><!-- /.inner-box -->*/
