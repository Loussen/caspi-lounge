<?php

/* default/template/common/search.twig */
class __TwigTemplate_dc324e82c7c3c33e16c30184e3f6e3de1d48f44d547bfed287332215df44b9df extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div id=\"search\" class=\"input-group top-search hidden-md-down\">
\t<div class=\"box-search\">
\t\t<input type=\"text\" name=\"search\" value=\"";
        // line 3
        echo (isset($context["search"]) ? $context["search"] : null);
        echo "\" placeholder=\"";
        echo (isset($context["text_search"]) ? $context["text_search"] : null);
        echo "\" />
\t\t<span class=\"btn-search\">
\t\t\t<button type=\"button\" class=\"waves-effect\"><img src=\"catalog/view/theme/default/images/icons/search.png\" alt=\"\"></button>
\t\t</span>
\t</div>
</div>";
    }

    public function getTemplateName()
    {
        return "default/template/common/search.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 3,  19 => 1,);
    }
}
/* <div id="search" class="input-group top-search hidden-md-down">*/
/* 	<div class="box-search">*/
/* 		<input type="text" name="search" value="{{ search }}" placeholder="{{ text_search }}" />*/
/* 		<span class="btn-search">*/
/* 			<button type="button" class="waves-effect"><img src="catalog/view/theme/default/images/icons/search.png" alt=""></button>*/
/* 		</span>*/
/* 	</div>*/
/* </div>*/
