<?php

/* default/template/extension/module/carousel.twig */
class __TwigTemplate_87c69660d6e0d8a0592d2b4ca4519f4d39b8b75a6c65d0ff5b2fe665916ea636 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<section class=\"flat-row flat-brand style2\" id=\"carousel";
        echo (isset($context["module"]) ? $context["module"] : null);
        echo "\">
  <div class=\"container\">
    <div class=\"row\">
      <div class=\"col-md-12\">
        <ul class=\"owl-carousel-5\">
          ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["banners"]) ? $context["banners"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["banner"]) {
            // line 7
            echo "          <li>
            ";
            // line 8
            if ($this->getAttribute($context["banner"], "link", array())) {
                // line 9
                echo "            <a href=\"";
                echo $this->getAttribute($context["banner"], "link", array());
                echo "\"><img src=\"";
                echo $this->getAttribute($context["banner"], "image", array());
                echo "\" alt=\"";
                echo $this->getAttribute($context["banner"], "title", array());
                echo "\" class=\"img-responsive\" /></a>
            ";
            } else {
                // line 11
                echo "            <img src=\"";
                echo $this->getAttribute($context["banner"], "image", array());
                echo "\" alt=\"";
                echo $this->getAttribute($context["banner"], "title", array());
                echo "\" class=\"img-responsive\" />
            ";
            }
            // line 13
            echo "          </li>
          ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['banner'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "        </ul><!-- /.owl-carousel-5 -->
      </div><!-- /.col-md-12 -->
    </div><!-- /.row -->
  </div><!-- /.container -->
</section><!-- /.flat-brand -->";
    }

    public function getTemplateName()
    {
        return "default/template/extension/module/carousel.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  62 => 15,  55 => 13,  47 => 11,  37 => 9,  35 => 8,  32 => 7,  28 => 6,  19 => 1,);
    }
}
/* <section class="flat-row flat-brand style2" id="carousel{{ module }}">*/
/*   <div class="container">*/
/*     <div class="row">*/
/*       <div class="col-md-12">*/
/*         <ul class="owl-carousel-5">*/
/*           {% for banner in banners %}*/
/*           <li>*/
/*             {% if banner.link %}*/
/*             <a href="{{ banner.link }}"><img src="{{ banner.image }}" alt="{{ banner.title }}" class="img-responsive" /></a>*/
/*             {% else %}*/
/*             <img src="{{ banner.image }}" alt="{{ banner.title }}" class="img-responsive" />*/
/*             {% endif %}*/
/*           </li>*/
/*           {% endfor %}*/
/*         </ul><!-- /.owl-carousel-5 -->*/
/*       </div><!-- /.col-md-12 -->*/
/*     </div><!-- /.row -->*/
/*   </div><!-- /.container -->*/
/* </section><!-- /.flat-brand -->*/
