<?php

namespace Squareup\Exception;

class Timeout extends \Exception {
    
}