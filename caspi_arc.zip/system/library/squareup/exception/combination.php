<?php

namespace Squareup\Exception;

class Combination extends \Exception {
    
}