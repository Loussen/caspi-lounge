<?php

// All in seconds
$_['squareup_cron_timeout_buffer'] = 300;
$_['squareup_cron_standard_period'] = 86400;
$_['squareup_cron_default_standard_timeout'] = $_['squareup_cron_standard_period'] - $_['squareup_cron_timeout_buffer'];
$_['squareup_cron_inventory_period'] = 1800;
$_['squareup_cron_default_inventory_timeout'] = $_['squareup_cron_inventory_period'] - $_['squareup_cron_timeout_buffer'];