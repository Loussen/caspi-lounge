<?php
$_['status']        = 1;
$_['collapse']      = 0;
$_['sort_order']    = 0;
$_['type']          = 'text';
$_['allowed_types'] = array('text');